import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from Mars import Mars

if __name__ == "__main__":
    list_count_iterations = []
    list_count_loss_colonies = []
    list_count_win_colonies = []
    list_lifetime = []
    params = [
        [500, 10, 20, 10],
        [200, 5, 20, 10],
        [1000, 20, 50, 20],
        [100, 3, 10, 10]
    ]
    all_survival_probabilities = []
    all_colonies_counts = []
    all_victory_probabilities = []
    all_iterations = []
    all_artifact_counts = []
    for param in params:
        survival_probabilities = []
        colonies_counts = []
        victory_probabilities = []
        for i in range(100):
            mars = Mars(param[0], param[1], param[2], param[3])
            count_iterations, count_loss_colonies, count_win_colonies = mars.main_cycle()
            list_count_iterations.append(count_iterations)
            list_count_loss_colonies.append(count_loss_colonies)
            list_count_win_colonies.append(count_win_colonies)
            list_lifetime.append(count_iterations)
            survival_probability = 1 - (count_loss_colonies / (count_loss_colonies + count_win_colonies))
            survival_probabilities.append(survival_probability)
            colonies_counts.append(param[1])
            victory_probability = count_win_colonies / (count_loss_colonies + count_win_colonies)
            victory_probabilities.append(victory_probability)
        all_survival_probabilities.extend(survival_probabilities)
        all_colonies_counts.extend(colonies_counts)
        all_victory_probabilities.extend(victory_probabilities)
        all_iterations.extend([param[0]] * 100)
        all_artifact_counts.extend([param[2]] * 100)

    plt.figure(figsize=(10, 6))
    plt.hist(list_lifetime, bins=30, edgecolor='black', alpha=0.7)
    plt.title("Распределение времени жизни колоний до поражения")
    plt.xlabel("Количество итераций до поражения")
    plt.ylabel("Частота")
    plt.grid(True)
    plt.show()

    plt.figure(figsize=(10, 6))
    sns.boxplot(x=all_colonies_counts, y=all_survival_probabilities)
    plt.title("Зависимость вероятности выживания от количества колоний")
    plt.xlabel("Количество колоний")
    plt.ylabel("Вероятность выживания")
    plt.grid(True)
    plt.show()

    plt.figure(figsize=(10, 6))
    sns.boxplot(x=all_colonies_counts, y=all_victory_probabilities)
    plt.title("Зависимость вероятности победы от количества колоний")
    plt.xlabel("Количество колоний")
    plt.ylabel("Вероятность победы")
    plt.grid(True)
    plt.show()

    plt.figure(figsize=(10, 6))
    plt.plot(all_iterations, all_survival_probabilities, marker='o', linestyle='-', color='r')
    plt.title("Зависимость вероятности выживания от числа итераций")
    plt.xlabel("Число итераций")
    plt.ylabel("Вероятность выживания")
    plt.grid(True)
    plt.show()
